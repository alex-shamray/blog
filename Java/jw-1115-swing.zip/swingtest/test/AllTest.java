/*
 * AllTest
 *
 */

package gov.fnal.foo;

import junit.framework.*;

/**
 * AllTest, runs all the tests
 */
public class AllTest extends TestCase {

	public AllTest(String name) {
		super(name);
	}

	public static Test suite() {
		TestSuite suite = new TestSuite();

		suite.addTest(FooTest.suite());

		return suite;
	}
}

// End of file
// vim: set ai ts=4 sw=4:
